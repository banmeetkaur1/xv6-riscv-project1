#include "kernel/types.h"
#include "user.h"
#include "kernel/param.h"
#define assert(x) if (x) { /* pass */ } else { \
printf("assert failed %s %s %d\n", #x , __FILE__, __LINE__); \
exit(0); \
}
void readfile(char *file, int howmany) {
int i;
// assumes file opens successfully...
int fd = open(file, 0);
char buf;
// assumes file is big enough...
for (i = 0; i < howmany; i++)
(void) read(fd, &buf, 1);
close(fd);
}
int
main(int argc, char *argv[])
{
int rc1 = getreadcount();
printf("Read count %d\n", rc1);
int rc = fork();
if (rc < 0) {
printf("Fork failed!\n");
exit(0);
}
readfile("README", 5);
if (rc > 0) {
int status;
wait(&status);
int rc2 = getreadcount();
printf("Read count %d\n", rc2);
assert((rc2 - rc1) == 10);
printf("TEST PASSED\n");
int fd1 = open("ls", 0);
int fd2 = open("syscallTest", 0);
int fd3 = open("cat", 0);
if(fd1 * fd2 * fd3 < 0){
printf("Open failed!\n");
exit(0);
}
close(fd1);
int of = getopenfilecount();
printf("Number of opened files %d\n", of - 3);
assert(of == 5);
printf("TEST PASSED\n");
close(fd2);
close(fd3);
}
exit(0);
}

